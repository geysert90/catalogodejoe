// pages/_app.js
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Preloader from "@/components/elements/Preloader";
import "swiper/css";
import "swiper/css/pagination";
import "../public/assets/css/style.css";

function MyApp({ Component, pageProps }) {
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);

  // 💡 Soluciona problemas de botones/menu al cambiar de página
  useEffect(() => {
    const handleRouteChange = () => {
      // Solución para reactivar botones y comportamientos que se rompen en mobile
      setTimeout(() => {
        if (typeof window !== "undefined") {
          // Esto forza el foco a comportarse como en page reload
          document.activeElement?.blur();

          // Si usas scripts que manipulan clases, reinítialos aquí si aplica
          // Por ejemplo: cerrar menú móvil si está abierto
          const menu = document.querySelector(".mobile-header-wrapper-style");
          if (menu?.classList.contains("mobile-header-active")) {
            menu.classList.remove("mobile-header-active");
          }
        }
      }, 200); // Esperamos un poco para que el DOM se estabilice
    };

    router.events.on("routeChangeComplete", handleRouteChange);
    return () => router.events.off("routeChangeComplete", handleRouteChange);
  }, [router.events]);

  return !loading ? <Component {...pageProps} /> : <Preloader />;
}

export default MyApp;
